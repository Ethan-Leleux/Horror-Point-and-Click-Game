from hallway import Hallway



if __name__ == "__main__":


    game_instance = Hallway()

    game_instance.run()
