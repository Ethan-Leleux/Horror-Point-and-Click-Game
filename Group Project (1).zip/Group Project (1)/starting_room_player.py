from starting_room import StartingRoom



if __name__ == "__main__":


    game_instance = StartingRoom()

    game_instance.run()
