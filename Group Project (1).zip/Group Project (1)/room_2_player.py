from room_2 import Room2



if __name__ == "__main__":


    game_instance = Room2()

    game_instance.run()
